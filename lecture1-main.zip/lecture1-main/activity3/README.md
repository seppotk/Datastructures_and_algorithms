# Git / Github

- Clone today's repo
- Create a new branch e.g answers
- Create a repository in GitHub
- Change remote to point to your repo

## Links

- [How To Change Git Remote Origin](https://devconnected.com/how-to-change-git-remote-origin/)
