# Outline

- Data structures & Abstract Data Types (ADT)
- Algorithms
- Course Mechanics?

---
