# Homework

## Task 1/3:Videos

- [Hashes 1](https://youtu.be/)
- [Hashes 2](https://youtube.com/watch?v=XYmI-T-JJso&si=EnSIkaIECMiOmarE)
- [Hashes 3](https://youtube.com/watch?v=YIoZQwWJIDA&si=EnSIkaIECMiOmarE)
- [Hashes 4](https://youtube.com/watch?v=jtMwp0FqEcg&si=EnSIkaIECMiOmarE)

## Task 2/3: Reading

- [Quick Sort In C++](https://www.softwaretestinghelp.com/quick-sort/)
- [Merge Sort In C++](https://www.softwaretestinghelp.com/merge-sort/)
- [Hash Table In C++](https://www.softwaretestinghelp.com/hash-table-cpp-programs/)
- [Linked List Operations](https://www.softwaretestinghelp.com/linked-list/)
- [Asymptotic Analysis and Upper Bounds](https://opendsa-server.cs.vt.edu/OpenDSA/Books/Everything/html/AnalAsymptotic.html)

## Task 3/3: Pre-Lecture (Videos)

- [Trees and heaps](https://youtube.com/watch?v=lhTCSGRAlXI&si=EnSIkaIECMiOmarE)
- [Heaps 1](https://youtube.com/watch?v=BzQGPA_v-vc&si=EnSIkaIECMiOmarE)
