# Links

- MIT 2011: Introduction to Algorithms
  https://ocw.mit.edu/courses/6-006-introduction-to-algorithms-fall-2011/pages/syllabus/
  https://www.youtube.com/watch?v=HtSuA80QTyo&list=PLUl4u3cNGP61Oq3tWYp6V_F-5jb5L2iHb
- MIT 2020: Introduction to Algorithms
  https://ocw.mit.edu/courses/6-006-introduction-to-algorithms-spring-2020/video_galleries/lecture-videos/
  https://www.youtube.com/playlist?list=PLUl4u3cNGP63EdVPNLG3ToM6LaEUuStEY
- Standford: [Algorithms Specialization](https://www.coursera.org/specializations/algorithms)
- Princeton: [Algorithms, Part I](https://www.coursera.org/learn/algorithms-part1), [Algorithms, Part II](https://www.coursera.org/learn/algorithms-part2)
- Misc
  - https://www.enjoyalgorithms.com/data-structures-and-algorithms-course/
  - https://kalkicode.com/
