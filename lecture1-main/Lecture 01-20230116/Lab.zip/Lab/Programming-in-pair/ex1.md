
# Exercise 1

# Part A

What is wrong with this program?

```cpp
#include <iostream>

int main()
{
    // prints "Hello,World!":
    cout << "Hello,World!\n"
}
```

# Part B

What is wrong with this program?

```cpp
#include <iostream>;

int main
{
    // prints "n = 22":
    n = 22;
    cout << "n = << n << endl;
}
```

## Part C

Write a program that prints the block letter “B” in a 7 × 6 grid of stars as shown in the figure letterb.cpp.
