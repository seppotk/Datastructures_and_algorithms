# Activities

## Task 1

- Refer to the following link. Discuss the characteristics of Greedy approach:
  https://www.geeksforgeeks.org/greedy-approach-vs-dynamic-programming/

## Task 2

- Explain how the code in `./src/fkp.cp`p works. Refer to the following link:
  https://www.geeksforgeeks.org/fractional-knapsack-problem/

## Task 3

- Explain how the code in `./src/asp.cpp` works. Refer to the following link:
  https://www.geeksforgeeks.org/activity-selection-problem-greedy-algo-1/

## Task 4: Individual (at home)

- Refer to te following link. Explain the differences between Greedy Algorithm and Dynamic Programming
  https://www.geeksforgeeks.org/greedy-approach-vs-dynamic-programming/

## Link(s)

- https://cpp.sh/
