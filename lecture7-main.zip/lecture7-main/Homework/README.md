# Homework

## Task 1/2: Reading

- [What is Greedy Algorithm: Example, Applications, Limitations and More](https://www.simplilearn.com/tutorials/data-structure-tutorial/greedy-algorithm)
- [Breadth First Search (BFS) C++ Program to Traverse a Graph Or Tree](https://www.softwaretestinghelp.com/cpp-bfs-program-to-traverse-graph/)
- [Depth First Search (DFS) C++ Program To Traverse A Graph Or Tree](https://www.softwaretestinghelp.com/cpp-dfs-program-to-traverse-graph/)

## Task 2/2: Pre-Lecture

- [Standard Template Library (STL): A Brief Introduction](https://www.softwaretestinghelp.com/standard-template-library-stl/)
