# Homework

## Task 1/3:Videos

- [Sorts 1 Introduction to sorts (~8min)]()
- [Sorts 2 Selection Sort (~5min)](https://youtu.be/fgYlVyrt1vE)
- [Sorts 3 Insertion Sort (~5min)](https://youtu.be/eTvQIbB-AuE)
- [Sorts 4 Insertion Sort Code (~4min)](https://youtu.be/3U2vTqaL7uE)
-

## Task 2/3: Reading

- [Bubble Sort In C++ With Examples](https://www.softwaretestinghelp.com/bubble-sort/)
- [Selection Sort In C++ With Examples](https://www.softwaretestinghelp.com/selection-sort/)
- [Insertion Sort In C++ With Examples](https://www.softwaretestinghelp.com/insertion-sort/)

## Task 3/3: Pre-Lecture

- [Quicksort](https://youtu.be/0SkOjNaO1XY)
- [Pointer to pointer in c++](https://youtu.be/d3kd5KbGB48)
- [Hash Tables and Dictionaries](https://youtu.be/sfWyugl4JWA)

## Recommended

- [C++ POINTERS FULL COURSE Beginner to Advanced (150min)](https://youtu.be/kiUGf_Z08RQ)
