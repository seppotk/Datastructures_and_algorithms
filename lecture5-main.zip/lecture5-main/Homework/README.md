# Homework

## Task 1/3:Videos

- [What Is Dynamic Programming and How To Use It](https://youtu.be/vYquumk4nWw)
- [0/1 Knapsack Problem](https://youtu.be/nLmhmB6NzcM)

## Task 2/3: Reading

- [The Staircase Problem](https://www.geeksforgeeks.org/count-ways-reach-nth-stair/)
- [0/1 Knapsack Problem](https://www.geeksforgeeks.org/0-1-knapsack-problem-dp-10/)
- [Dynamic Programming](https://www.geeksforgeeks.org/dynamic-programming/)
- [Recursion](https://opendsa-server.cs.vt.edu/OpenDSA/Books/Everything/html/RecIntro.html)

## Task 3/3: Pre-Lecture (Videos)

- [Trees and heaps](https://youtube.com/watch?v=lhTCSGRAlXI&si=EnSIkaIECMiOmarE)
- [Heaps 1](https://youtube.com/watch?v=BzQGPA_v-vc&si=EnSIkaIECMiOmarE)
