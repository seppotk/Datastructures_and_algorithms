# Homework

## Task 1/3: Reading

- [Introduction To Searching Algorithms In C++](https://www.softwaretestinghelp.com/searching-algorithms-in-cpp/)

> Remember that in many literature, Binary search is referred to use divide-and-conquer technique. However this is not the case, it uses Decrease-and-Conquer.

## Task 2/3:Videos

- [Introduction to Recursion (~23min)](https://youtu.be/B0NtAFf4bvU)
- [Introduction to Binary Search (~14min)](https://youtu.be/6ysjqCUv3K4)

## Task 3/3: Pre-Lecture

- [Introduction to Linked Lists (~19min)](https://youtu.be/WwfhLC16bis)

## Recommended

- https://www.learncpp.com/
