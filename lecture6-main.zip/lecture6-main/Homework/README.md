# Homework

## Task 1/3:Videos

- [Heap - Heap Sort - Heapify - Priority Queues](https://youtu.be/HqPJF2L5h9U)
- [Binary Search Tree](https://youtu.be/vLS-zRCHo-Y)

## Task 2/3: Reading

- [Binary Search Tree C++](https://www.softwaretestinghelp.com/binary-search-tree-in-cpp/)
- [Heap Data Structure In C++](https://www.softwaretestinghelp.com/avl-trees-and-heap-data-structure-in-cpp/)

## Task 3/3: Pre-Lecture

- [Greedy Method](https://youtu.be/ARvQcqJ_-NY)
- [MultiStage Graph](https://youtu.be/9iE9Mj4m8jk)
